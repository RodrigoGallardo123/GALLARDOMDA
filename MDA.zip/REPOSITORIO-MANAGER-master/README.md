﻿# REPOSITORIO MANAGER

Repositorio Manager Script 

 • EN ESTE REPOSITORIO SE ENCUENTRAN LOS ARCHIVOS ORIGINALES DE AMBOS MÁNAGER


==================================================================================

☆ https://t.me/admmanagerfree ☆
=================================================
TEAM [ ILLUMINATI ⃘⃤꙰✰ ] @El_Gato

[ FULL SCRIPTS ⃘⃤꙰✰ ] && VPS